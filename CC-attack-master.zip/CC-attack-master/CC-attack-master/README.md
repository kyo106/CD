# CC-attack
Use Socks5 proxy to ddos(Http-Flood) attack.

(It supports socks4 too.)

And now it is upgraded to python3 version.

# Install

    pip3 install pysocks
    git clone https://github.com/Leeon123/CC-attack.git
    cd CC-attack

# Usage

    python3 cc.py
    
      ____ ____        _   _   _             _
     / ___/ ___|      / \ | |_| |_ __ _  ___| | __
    | |  | |   _____ / _ \| __| __/ _` |/ __| |/ /
    | |__| |__|_____/ ___ \ |_| || (_| | (__|   <
     \____\____|   /_/   \_\__|\__\__,_|\___|_|\_\
    Python3 version 1.1
                                Cobed by Leeon123
    >---------------------------------------------<
                If you want to stop
               this script, pls just
                 close the window.
    >---------------------------------------------<
    > Host/Ip:
    > Page you want to attack:
    > Port:
    > Threads:
    > Proxy file path(proxy.txt):
    > Number Of Proxies:
    > Input the Magnification:
